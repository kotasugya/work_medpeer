FactoryBot.define do
  factory :category do
    name { "カテゴリー" }
  end
end