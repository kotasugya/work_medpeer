require 'rails_helper'

RSpec.describe "Categories", type: :request do
  describe "GET /index" do
    pending "add some examples (or delete) #{__FILE__}"
  end
end
