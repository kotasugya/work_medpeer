FactoryBot.define do
  factory :idea do
    body { "MyString" }
  end
end

