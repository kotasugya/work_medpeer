class Idea < ApplicationRecord
  validates :body, presence: true
end
